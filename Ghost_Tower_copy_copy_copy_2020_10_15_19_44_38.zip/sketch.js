var tower,towerimg;
var door,doorimg, doorGroup;
var railing,railingimg,railingGroup;
var ghost,ghostimg;
var invisibleblock,invisibleblockGroup

var gameState = "play";
 
function preload(){
  towerimg = loadImage("tower.png");
  
  doorimg = loadImage("door.png");
  
  railingimg = loadImage("climber.png");
  
  ghostimg = loadImage("ghost-standing.png");
  
  spookysound = loadSound("spooky.wav");
  
}
function setup(){
  createCanvas(600,600);
  spookysound.loop();
  
  tower = createSprite(300,300);
  tower.addImage("tower",towerimg);
  tower.velocityY = 1;
  
  doorGroup = new Group();
  
  railingGroup = new Group();
  
  invisibleblockGroup = new Group();
  
  ghost = createSprite(200,200,50,50);
  ghost.addImage("ghost",ghostimg);
  ghost.scale = 0.5;
  
}
function draw(){
  background(0);
  
  if(gameState=="play"){
  
  if(tower.y>400){
    tower.y=300;
  }
  
  if(keyDown("left")){
  ghost.x-=3;
  }
  
  if(keyDown("right")){
    ghost.x+=3;
  }
  if(keyDown("space")){
    ghost.velocityY = -5;
  }
  
  ghost.velocityY+=0.8;
    
  if(railingGroup.isTouching(ghost)){
    ghost.velocityY= 0;
  }
  if(invisibleblockGroup.isTouching(ghost)|| ghost.y>600){
    ghost.destroy();
    gameState = "end";
  }
    
  doors();
  drawSprites();
  }
  
  if(gameState=="end"){
    stroke("yellow");
    fill("yellow");
    textSize(30);
    text("GAME OVER!",230,450);
  }
}
function doors(){
  if(frameCount% 240==0){
    door = createSprite(200,-50);
    door.addImage("door",doorimg);
    door.x = Math.round(random(120,400));
    door.velocityY = 1;
    door.lifetime = 800;
    ghost.depth = door.depth;
    ghost.depth+=1;
    
    doorGroup.add(door);
    
    railing = createSprite(200,10);
    railing.addImage("railing",railingimg);
    railing.x = door.x;
    railing.velocityY = 1;
    railing.lifetime = 800;
    
    railingGroup.add(railing);
    
    invisibleblock = createSprite(200,15)
    invisibleblock.width = railing.width;
    invisibleblock.height = railing.height;
    invisibleblock.x = door.x
    invisbleblock.velocityY = 1;
    invisibleblock.debug = true;
    
    invisibleblockGroup.add(invisileblock);
  }
}